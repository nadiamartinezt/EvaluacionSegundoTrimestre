package TestParejas;

import java.util.ArrayList;

public class Usuario extends PersonasClasePadre{
	
	// Atributos
	protected int edad;
	protected double peso;
	protected int altura;
	protected String colorCabello;
	protected String generoAlta;
	// Lo usaremos para saber si le gustan los animales
	protected String animal;
	// Lo usaremos para saber si le gustaria formar una familia
	protected String familia;
	protected String generoBusca;
	protected ArrayList<Integer> listaPersonasGustoId;
	
	
	// Constructores
	protected Usuario() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected Usuario(int idAlta, String nombre, String apellido, String userName) {
		super(idAlta, nombre, apellido, userName);
		// TODO Auto-generated constructor stub
	}
	
	//modificado pasando valores de padre
	protected Usuario(int idAlta, String nombre, String apellido, String userName, int edad, double peso, int altura, String colorCabello, String generoAlta, String animal,
			String familia, String generoBusca, ArrayList<Integer> listaPersonasGustoId) {
		super(idAlta, nombre, apellido, userName);
		this.edad = edad;
		this.peso = peso;
		this.altura = altura;
		this.colorCabello = colorCabello;
		this.generoAlta = generoAlta;
		this.animal = animal;
		this.familia = familia;
		this.generoBusca = generoBusca;
		this.listaPersonasGustoId = listaPersonasGustoId;
	}

	protected int getEdad() {
		return edad;
	}

	protected void setEdad(int edad) {
		this.edad = edad;
	}

	protected double getPeso() {
		return peso;
	}

	protected void setPeso(double peso) {
		this.peso = peso;
	}

	protected int getAltura() {
		return altura;
	}

	protected void setAltura(int altura) {
		this.altura = altura;
	}

	protected String getColorCabello() {
		return colorCabello;
	}

	protected void setColorCabello(String colorCabello) {
		this.colorCabello = colorCabello;
	}

	protected String getGeneroAlta() {
		return generoAlta;
	}

	protected void setGeneroAlta(String generoAlta) {
		this.generoAlta = generoAlta;
	}

	protected String getAnimal() {
		return animal;
	}

	protected void setAnimal(String animal) {
		this.animal = animal;
	}

	protected String getFamilia() {
		return familia;
	}

	protected void setFamilia(String familia) {
		this.familia = familia;
	}

	protected String getGeneroBusca() {
		return generoBusca;
	}

	protected void setGeneroBusca(String generoBusca) {
		this.generoBusca = generoBusca;
	}

	protected ArrayList<Integer> getListaPersonasGustoId() {
		return listaPersonasGustoId;
	}

	protected void setListaPersonasGustoId(ArrayList<Integer> listaPersonasGustoId) {
		this.listaPersonasGustoId = listaPersonasGustoId;
	}

	@Override
	public String toString() {
		return "Usuario [edad=" + edad + ", peso=" + peso + ", altura=" + altura + ", colorCabello=" + colorCabello
				+ ", generoAlta=" + generoAlta + ", animal=" + animal + ", familia=" + familia + ", generoBusca="
				+ generoBusca + ", listaPersonasGustoId=" + listaPersonasGustoId + ", idAlta=" + idAlta + ", nombre="
				+ nombre + ", apellido=" + apellido + ", userName=" + userName + "]";
	}
	
	
	
	
	
	
	
	
	
	
	

}
