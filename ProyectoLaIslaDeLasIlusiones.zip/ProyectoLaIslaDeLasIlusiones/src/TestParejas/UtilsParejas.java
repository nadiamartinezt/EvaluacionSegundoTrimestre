package TestParejas;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class UtilsParejas {

	// Método para capturar el valor del scanner
	public static int capturaValorMenu(String textoMenu, int opcionMaxima) {
		Scanner scanner = new Scanner(System.in);
		int opcionElegida = 0;
		boolean opcionInvalida;
		do {
			opcionInvalida = true;
			System.out.println(textoMenu);
			// Comprobamos si la entrada del usuario es un entero
			if (scanner.hasNextInt()) {
				opcionElegida = scanner.nextInt();
				// Si la opción elegida es válida
				if (opcionElegida >= 1 && opcionElegida <= opcionMaxima) {
					opcionInvalida = false;
				} else {
					System.out.println("Opción inválida. Por favor, elija una opción del 1 al " + opcionMaxima + "\n");
				}
			} else {
				// Si no es un numero entero entra else
				System.out.println("Entrada inválida. Por favor, introduzca un número valido.");
				scanner.next(); //
			}

		} while (opcionInvalida);

		return opcionElegida;

	}

	// Método para obtener por scanner una opción de tipo String

	public static String getString(String texto) {
		Scanner scanner = new Scanner(System.in);
		String nombre = "";
		boolean isNuloNombre = true;

		do {
			System.out.println(texto);
			nombre = scanner.nextLine();
			if (nombre.equalsIgnoreCase("")) {
				System.out.println("Por favor introduce al menos un caracter!");
				isNuloNombre = true;
			} else {
				isNuloNombre = false;

			}
		} while (isNuloNombre);

		return nombre;
	}

	// Método para obtener por scanner una opción de tipo int
	public static int getNumberEntero(String texto) {
		Scanner scanner = new Scanner(System.in);
		int number = 0;
		boolean isNuloNumber;
		do {
			isNuloNumber = true;
			System.out.println(texto);
			if (scanner.hasNextInt()) {
				number = scanner.nextInt();
				if (number == 0) {
					System.out.println("Por favor introduce al menos un caracter!");
					isNuloNumber = true;
				} else {
					isNuloNumber = false;
				}
			} else {
				// Si no es un numero entero entra else
				System.out.println("Entrada inválida. Por favor, introduzca un número valido.");
				scanner.next(); //
			}
		} while (isNuloNumber);

		return number;
	}

	// Método para obtener por scanner una opción de tipo DOUBLE
	public static double capturaValorDouble(String textoMenu, Double opcionMaxima) {
		Scanner scanner = new Scanner(System.in);
		double opcionElegida = 0;
		boolean opcionInvalida;
		do {
			opcionInvalida = true;
			System.out.println(textoMenu);
			// Comprobamos si la entrada del usuario es un double

			if (scanner.hasNextDouble()) {
				opcionElegida = scanner.nextDouble();

				// Si la opción elegida es válida
				if (opcionElegida >= 40 && opcionElegida <= 300) {
					opcionInvalida = false;
				} else {
					System.out.println("Opción inválida. Por favor, elija una opción del 1 al " + opcionMaxima + "\n");
				}
			} else {
				// Si no es un numero entero entra else
				System.out.println("Entrada inválida. Por favor, introduzca un número valido.");
				scanner.next(); //
			}

		} while (opcionInvalida);

		return opcionElegida;

	}

	// Método para emparejar
	public static void buscarPersona(PersonasClasePadre[] listPersonasClasePadre, int idUsuarioLogueado,
			String userNameUsuarioLogueado, Usuario usuarioLogueado) {

		boolean menuBuscaPersona;
		String opcionMenuBuscaPersona;
		Scanner scannerMenuBuscaPersona = new Scanner(System.in);

		do {

			menuBuscaPersona = true;

			System.out.println(" \n ********** <3 La Isla de las Ilusiones <3 ********** \n" + "\n¿Que desea hacer?: \n"
					+ "1. Filtrar por tu misma edad \n" + "2. Personas con mas datos en común \n"
					+ "3. Busqueda aleatoria \n" + "4. Salir al menu anterior \n");
			System.out.println("***************************************************** ");
			opcionMenuBuscaPersona = scannerMenuBuscaPersona.nextLine();

			switch (opcionMenuBuscaPersona) {
			// Filtrar por tu misma edad
			case "1":
				Usuario usuarioGusta = new Usuario();

				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null && listPersonasClasePadre[i] instanceof Usuario) {
						if (((Usuario) listPersonasClasePadre[i]).getEdad() == usuarioLogueado.getEdad()) {
							System.out.println("Usuario: \n" + listPersonasClasePadre[i].toString());
						}
					}
				}

				int numeroIdMismaEdad = getNumberEntero(
						"\nIntroduce el id de la persona que quieres añadir a tu lista de gustos ");
				boolean existeIdPersona = false;
				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null && listPersonasClasePadre[i] instanceof Usuario) {
						if (listPersonasClasePadre[i].getIdAlta() == numeroIdMismaEdad) {
							usuarioGusta = (Usuario) listPersonasClasePadre[i];
							ArrayList<Integer> listaIdGustos = usuarioLogueado.getListaPersonasGustoId();
							listaIdGustos.add(usuarioGusta.getIdAlta());
							usuarioLogueado.setListaPersonasGustoId(listaIdGustos);
							existeIdPersona = true;
							System.out.println("se ha añadido a tu lista de gustos");
							break;
						}
					}
				}

				if (!existeIdPersona) {
					System.out.println("No existe ningun usuario con ese id");
				}

				menuBuscaPersona = true;
				break;
			// Personas con mas datos en común
			case "2":

				Usuario usuarioGustaCase2 = new Usuario();
				System.out.println("Introduce los datos por los que quieres buscar");
				int cabello = UtilsParejas
						.capturaValorMenu("Indica color de cabello: \n 1. Moreno \n 2. Rubio \n 3. Pelirrojo: ", 3);
				String listCabello[] = { "Moreno", "Rubio", "Pelirrojo" };
				String tipoCabello = listCabello[cabello - 1];

				int animal = UtilsParejas.capturaValorMenu("Indica tipo de mascota favorita: \n 1. Animales domesticos "
						+ "\n 2. Animales exoticos \n 3. Animales que viven en otra casa", 3);
				String listAnnimales[] = { "Animales domesticos", "Animales exoticos",
						"Animales que viven en otra casa" };
				String tipoGustoAnimal = listAnnimales[animal - 1];

				int familia = UtilsParejas.capturaValorMenu(
						"Le gustaria tener familia ... algun dia" + " : \n 1. Si \n 2. No \n 3. Familia de animalitos",
						3);
				String listFamilia[] = { "Si", "No", "Familia de animalitos" };
				String tipoFamilia = listFamilia[familia - 1];

				int generoBusca = UtilsParejas.capturaValorMenu(
						"Indica que quieres que busque: \n 1. Mujer \n 2. Hombre \n 3. Sin genero definido", 3);
				String listGeneroBusca[] = { "Mujer", "Hombre", "Sin genero definido" };
				String tipoGeneroBusca = listGeneroBusca[generoBusca - 1];

				PersonasClasePadre[] auxPersonas = new PersonasClasePadre[listPersonasClasePadre.length];

				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null && listPersonasClasePadre[i] instanceof Usuario) {
						if (((Usuario) listPersonasClasePadre[i]).getColorCabello().equalsIgnoreCase(tipoCabello)
								&& ((Usuario) listPersonasClasePadre[i]).getAnimal().equalsIgnoreCase(tipoGustoAnimal)
								&& ((Usuario) listPersonasClasePadre[i]).getFamilia().equalsIgnoreCase(tipoFamilia)
								&& ((Usuario) listPersonasClasePadre[i]).getGeneroBusca()
										.equalsIgnoreCase(tipoGeneroBusca)) {
							System.out.println("Usuario: \n" + listPersonasClasePadre[i].toString());
							auxPersonas[i] = listPersonasClasePadre[i];
						}
					}
				}

				int numeroIdDatosComun = getNumberEntero(
						"\nIntroduce el id de la persona que quieres añadir a tu lista de gustos");
				boolean existeIdDatosComun = false;
				for (int i = 0; i < auxPersonas.length; i++) {
					if (auxPersonas[i] != null && auxPersonas[i] instanceof Usuario) {
						if (auxPersonas[i].getIdAlta() == numeroIdDatosComun) {
							usuarioGustaCase2 = (Usuario) auxPersonas[i];
							ArrayList<Integer> listaIdGustos = usuarioLogueado.getListaPersonasGustoId();
							listaIdGustos.add(usuarioGustaCase2.getIdAlta());
							usuarioLogueado.setListaPersonasGustoId(listaIdGustos);
							existeIdDatosComun = true;
							System.out.println("se ha añadido a tu lista de gustos");
							break;
						}
					}
				}

				if (!existeIdDatosComun) {
					System.out.println("No existe ningun usuario con ese id");
				}

				menuBuscaPersona = true;
				break;

			// Búsqueda aleatoria
			case "3":
				Random random = new Random();
				boolean encuentraPersona = false;
				Usuario usuario = new Usuario();
				do {
					int numeroRandom = random.nextInt(listPersonasClasePadre.length);

					if (listPersonasClasePadre[numeroRandom] != null
							&& listPersonasClasePadre[numeroRandom] instanceof Usuario) {
						usuario = (Usuario) listPersonasClasePadre[numeroRandom];
						System.out.println(usuario.toString());
						encuentraPersona = true;
					}

				} while (!encuentraPersona);

				if (usuario != null) {
					ArrayList<Integer> listaIdGustos = usuarioLogueado.getListaPersonasGustoId();
					listaIdGustos.add(usuario.getIdAlta());
					usuarioLogueado.setListaPersonasGustoId(listaIdGustos);
				}

				menuBuscaPersona = true;
				break;
			// salir
			case "4":

				menuBuscaPersona = false;
				break;
			// opcion erronea
			default:
				System.out.println("Por favor para ayudarte a encontrar lo que buscas indica un valor correcto");
				menuBuscaPersona = true;
				break;
			}

		} while (menuBuscaPersona);

	}

}
