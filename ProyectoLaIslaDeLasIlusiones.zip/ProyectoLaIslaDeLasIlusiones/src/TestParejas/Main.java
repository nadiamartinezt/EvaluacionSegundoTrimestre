package TestParejas;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		boolean repetirMenu;
		boolean idCorrecto;
		boolean userNameCorrecto;
		Scanner scanner = new Scanner(System.in);
		String opcionMenuPrincipal;
		int numeroIdLogin;
		String userNameLogin;
		int cantidadPersonasId = 5;

		// Para poder realizar pruebas del programa creamos 4 usuarios y 1 administrador
		Administrador administrador = new Administrador(1, "Manuel", "Navas", "Mannav", "Director");
		Usuario usuario1 = new Usuario(2, "Alejandro", "Garcia", "Alegar", 20, 50, 170, "Moreno", "Hombre",
				"Animales domesticos", "Si", "Mujer", new ArrayList<>());
		Usuario usuario2 = new Usuario(3, "Sergio", "Garcia", "Sergar", 21, 55, 175, "Rubio", "Hombre",
				"Animales domesticos", "Si", "Mujer", new ArrayList<>());
		Usuario usuario3 = new Usuario(4, "Nadia", "Garcia", "Nadgar", 20, 50, 170, "Moreno", "Hombre",
				"Animales domesticos", "Si", "Hombre", new ArrayList<>());
		Usuario usuario4 = new Usuario(5, "Laura", "Garcia", "Laugar", 21, 55, 175, "Rubio", "Hombre",
				"Animales domesticos", "Si", "Hombre", new ArrayList<>());

		// Añadimos los objetos creados arriba a nuestra lista listPersonaClasePadre
		PersonasClasePadre listPersonasClasePadre[] = new PersonasClasePadre[8];
		listPersonasClasePadre[0] = administrador;
		listPersonasClasePadre[1] = usuario1;
		listPersonasClasePadre[2] = usuario2;
		listPersonasClasePadre[3] = usuario3;
		listPersonasClasePadre[4] = usuario4;

		do {

			/*
			 * Para realizar las pruebas pintamos el toString al principio para confirmar
			 * los datos que se van ingeresando, lo dejamos comentado en caso de que sea mas
			 * facil asi realizar las pruebas correspondientes
			 * 
			 * for (int i = 0; i < listPersonasClasePadre.length; i++) { if
			 * (listPersonasClasePadre[i] != null) { System.out.println("Usuario: \n" +
			 * listPersonasClasePadre[i].toString()); } }
			 * 
			 */

			repetirMenu = true;

			System.out.println(" \n ********** <3 La Isla de las Ilusiones <3 ********** \n" + "\n¿Que desea hacer?: \n"
					+ "1. Iniciar sesión \n" + "2. Darse de alta \n" + "3. Salir del programa\n");
			System.out.println("***************************************************** ");
			opcionMenuPrincipal = scanner.nextLine();

			switch (opcionMenuPrincipal) {
			// Iniciar sesión
			case "1":

				idCorrecto = false;
				userNameCorrecto = false;
				PersonasClasePadre personaLogueada = new PersonasClasePadre();
				numeroIdLogin = UtilsParejas.getNumberEntero("Introduce tu ID");
				// Se confirma que el id introducido esté en nuestra lista y que no sea un valor
				// nulo, si es así nos han dado un id correcto
				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null) {
						if (listPersonasClasePadre[i].getIdAlta() == numeroIdLogin) {
							idCorrecto = true;
							break;
						}
					}
				}

				userNameLogin = UtilsParejas.getString("Introduce tu username:");
				// Se confirma que el username introducido esté en nuestra lista y que no sea un
				// valor nulo, si es así nos han dado un username correcto
				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null) {
						if (listPersonasClasePadre[i].getUserName().equalsIgnoreCase(userNameLogin) && idCorrecto) {
							personaLogueada = listPersonasClasePadre[i];
							userNameCorrecto = true;
							break;
						}
					}
				}
				// Cuando tenemos el valor del id y del username que coinciden con lo registrado
				// en nuestra lista entramos en el if
				if (userNameCorrecto && idCorrecto) {

					if (personaLogueada instanceof Usuario) { // casteo a que sea un usuario
						menuSecundario(listPersonasClasePadre, numeroIdLogin, userNameLogin, (Usuario) personaLogueada);
					} else if (personaLogueada instanceof Administrador) { // casteo a que sea un administrador
						cantidadPersonasId = menuSecundarioAdministrador(listPersonasClasePadre, numeroIdLogin,
								userNameLogin, (Administrador) personaLogueada, cantidadPersonasId);
					}

				}
				// En caso de que no coincida el id con el username mostramos un mensaje por
				// pantalla al usuario
				else {
					System.out.println("El id: " + numeroIdLogin + " y el UserName: " + userNameLogin
							+ " introducidos no son correctos");
				}

				repetirMenu = true;
				break;

			// Darse de alta
			case "2":
				// Nuestro programa lo realizamos con un límite en caso de llegar al mismo no se
				// podrán realizar más altas
				if (cantidadPersonasId >= listPersonasClasePadre.length) {
					System.out.println("No podemos realizar su alta, hemos llegado al limite de usuarios");
				} else {

					PersonasClasePadre nuevaPersonasClasePadre = darseDeAltaUsuario(cantidadPersonasId);
					// Para dar de alta recorremos nuestra lista comprobamos su espacio y que exista
					// un espacio vacio en el que añadiremos
					// un nuevo alta

					for (int i = 0; i < listPersonasClasePadre.length; i++) {
						if (listPersonasClasePadre[i] == null) {
							listPersonasClasePadre[i] = nuevaPersonasClasePadre;
							break;
						}
					}

					cantidadPersonasId++;
					/*
					 * Para confirmar que se suman correctamente las altas nuevas pintamos un Syso
					 * que nos indique la cantidad del contador, lo dejamos comentado para facilitar
					 * las pruebas correspondientes contadorId++; System.out.println("contadorId:" +
					 * contadorId);
					 */
					System.out.println("se ha dado de alta al usuario nuevo");
					System.out.println("Recuerda para poder acceder tu ID: " + nuevaPersonasClasePadre.getIdAlta()
							+ " y tu username: " + nuevaPersonasClasePadre.getUserName());
				}

				repetirMenu = true;
				break;

			// Salir
			case "3":
				System.out.println("Esperamos verte pronto en La Isla de las Ilusiones ¡Hasta la proxima!");
				// Para salir del menu cambiamos el valor del boolean a false de manera que sale
				// del programa
				repetirMenu = false;
				break;

			// Opcion incorrecta
			default:
				// Mostramos el mensaje al usuario en caso de que se equivoque al ingresar un
				// valor
				System.out.println("Por favor para ayudarte a encontrar lo que buscas indica un valor correcto");
				repetirMenu = true;
				break;
			}

		} while (repetirMenu);

	}

	// Método creado para que el usuario una vez ingrese nos indique que va a desear
	// realizar dentro de su cuenta
	public static void menuSecundario(PersonasClasePadre[] listPersonasClasePadre, int idUsuarioLogueado,
			String userNameUsuarioLogueado, Usuario usuarioLogueado) {
		boolean menuSecundario;
		String opcionMenusecuandario;
		Scanner scannerMenusecundario = new Scanner(System.in);

		do {

			menuSecundario = true;

			System.out.println(" \n ********** <3 La Isla de las Ilusiones <3 ********** \n" + "\n¿Que desea hacer?: \n"
					+ "1. Buscar persona \n" + "2. Darse de baja \n" + "3. Desloguearse\n");
			System.out.println("***************************************************** ");
			opcionMenusecuandario = scannerMenusecundario.nextLine();

			switch (opcionMenusecuandario) {
			// Buscar persona
			case "1":

				UtilsParejas.buscarPersona(listPersonasClasePadre, idUsuarioLogueado, userNameUsuarioLogueado,
						usuarioLogueado);

				menuSecundario = true;
				break;
			// Darse de baja
			case "2":
				/*
				 * Para eliminar el registro de un usuario recorremos nuestra lista, verificamos
				 * que el valor no sea nulo y dado que el id es único y debe coincidir con un
				 * mismo username es necesario cumplir los dos requisitos para poder eliminar
				 * ese usuario en concreto. Confirmadas las dos condiciones le asignamos un
				 * valor nulo y se vuelve al menu principal
				 */
				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null) {
						if (listPersonasClasePadre[i].getIdAlta() == idUsuarioLogueado
								&& listPersonasClasePadre[i].getUserName().equalsIgnoreCase(userNameUsuarioLogueado)) {
							listPersonasClasePadre[i] = null;
							break;
						}
					}
				}

				System.out.println("Su usuario ha sido dado de baja ¡Hasta la proxima!");
				menuSecundario = false;
				break;

			// Desloguearse
			case "3":
				/*
				 * Para volver al menu principal desde el menu de usuario se crea la opcion de
				 * desloguearse, se muestra un mensaje de despedida y se vuelve al menu
				 * principal
				 */
				System.out.println("Esperamos verte pronto en La Isla de las Ilusiones ¡Hasta la proxima!");
				menuSecundario = false;
				break;

			// Opcion incorrecta
			default:
				System.out.println("Por favor para ayudarte a encontrar lo que buscas indica un valor correcto");
				menuSecundario = true;
				break;
			}

		} while (menuSecundario);

	}

	/*
	 * Método para poder dar de alta un usuario: Primero le añadimos un id mediante
	 * el contador. Se guardan las opciones que va indicando el usuario por scanner
	 * en UsuarioNuevo, luego seteamos las mismas
	 */

	public static Usuario darseDeAltaUsuario(int contadorId) {

		Usuario usuarioNuevo = new Usuario();
		contadorId++;
		usuarioNuevo.setIdAlta(contadorId);

		String nombre = UtilsParejas.getString("Nombre: ");
		usuarioNuevo.setNombre(nombre);

		String apellido = UtilsParejas.getString("Apellido: ");
		usuarioNuevo.setApellido(apellido);

		String userName = UtilsParejas.getString("Username: ");
		usuarioNuevo.setUserName(userName);

		int edad = UtilsParejas.getNumberEntero("Indica tu edad");
		usuarioNuevo.setEdad(edad);

		double peso = UtilsParejas.capturaValorDouble("¿Cual es su peso? (para valores con decimales usar coma , )",
				300.0);
		usuarioNuevo.setPeso(peso);

		int altura = UtilsParejas.getNumberEntero("Indica tu altura en cm");
		usuarioNuevo.setAltura(altura);

		int cabello = UtilsParejas
				.capturaValorMenu("Indica tu color de cabello: \n 1. Moreno \n 2. Rubio \n 3. Pelirrojo: ", 3);
		String listCabello[] = { "Moreno", "Rubio", "Pelirrojo" };
		usuarioNuevo.setColorCabello(listCabello[cabello - 1]);

		int generoAlta = UtilsParejas
				.capturaValorMenu("Indica tu genero: \n 1. Mujer \n 2. Hombre \n 3. Sin genero definido", 3);
		String listGenero[] = { "Mujer", "Hombre", "Sin genero definido" };
		usuarioNuevo.setGeneroAlta(listGenero[generoAlta - 1]);

		int animal = UtilsParejas.capturaValorMenu("Indica tu tipo de mascota favorita: \n 1. Animales domesticos "
				+ "\n 2. Animales exoticos \n 3. Animales que viven en otra casa", 3);
		String listAnnimales[] = { "Animales domesticos", "Animales exoticos", "Animales que viven en otra casa" };
		usuarioNuevo.setAnimal(listAnnimales[animal - 1]);

		int familia = UtilsParejas.capturaValorMenu(
				"Te gustaria tener familia ... algun dia" + " : \n 1. Si \n 2. No \n 3. Familia de animalitos", 3);
		String listFamilia[] = { "Si", "No", "Familia de animalitos" };
		usuarioNuevo.setFamilia(listFamilia[familia - 1]);

		int generoBusca = UtilsParejas
				.capturaValorMenu("Indica lo que buscas: \n 1. Mujer \n 2. Hombre \n 3. Sin genero definido", 3);
		String listGeneroBusca[] = { "Mujer", "Hombre", "Sin genero definido" };
		usuarioNuevo.setGeneroBusca(listGeneroBusca[generoBusca - 1]);

		/*
		 * Al finalizar de crear el objeto usuarioNuevo tambien se inicializa un array
		 * vacio en el cual podremos guardar más adelante su lista de personas que le
		 * gustan
		 */

		usuarioNuevo.setListaPersonasGustoId(new ArrayList<>());

		return usuarioNuevo;

	}

	/*
	 * Como complicación dentro del programa se opta por crear una cuenta de
	 * Administrador, la cual podrá visualizar todos los usuarios, podrá también
	 * añadir un nuevo alta en Director, Administrador, Responsable o Recursos
	 * Humanos. A su vez siempre está restringido su id para los otros usuarios
	 * cuando buscan pareja.
	 */
	public static int menuSecundarioAdministrador(PersonasClasePadre[] listPersonasClasePadre, int idUsuarioLogueado,
			String userNameUsuarioLogueado, Administrador personaLogueada, int cantidadPersonasId) {

		boolean menuSecundarioAdministrador;
		String opcionMenusecuandarioAdministrador;
		Scanner scannerMenusecundarioAdministrador = new Scanner(System.in);

		do {

			menuSecundarioAdministrador = true;

			System.out.println(" \n ********** <3 La Isla de las Ilusiones <3 ********** \n" + "\n¿Que desea hacer?: \n"
					+ "1. Listar usuarios \n" + "2. Dar de alta administrador \n" + "3. Desloguearse\n");
			System.out.println("***************************************************** ");
			opcionMenusecuandarioAdministrador = scannerMenusecundarioAdministrador.nextLine();

			switch (opcionMenusecuandarioAdministrador) {
			// Listar usuarios
			case "1":
				for (int i = 0; i < listPersonasClasePadre.length; i++) {
					if (listPersonasClasePadre[i] != null) {
						System.out.println("Usuario: \n" + listPersonasClasePadre[i].toString());
					}
				}
				menuSecundarioAdministrador = true;
				break;
			// Dar de alta administrador
			case "2":
				if (cantidadPersonasId >= listPersonasClasePadre.length) {
					System.out.println("No podemos realizar un alta, hemos llegado al limite de usuarios");
				} else {
					PersonasClasePadre nuevaPersonasClasePadre = darDeAltaAdministrador(cantidadPersonasId);

					for (int i = 0; i < listPersonasClasePadre.length; i++) {
						if (listPersonasClasePadre[i] == null) {
							listPersonasClasePadre[i] = nuevaPersonasClasePadre;
							break;
						}
					}

					cantidadPersonasId++;
					// contadorId++;
					System.out.println("se ha dado de alta al administrador nuevo");
					System.out.println("Recuerda para poder acceder tu ID: " + nuevaPersonasClasePadre.getIdAlta()
							+ " y tu username: " + nuevaPersonasClasePadre.getUserName());
				}
				menuSecundarioAdministrador = true;
				break;

			// Desloguearse
			case "3":
				System.out.println("Esperamos verte pronto en La Isla de las Ilusiones ¡Hasta la proxima!");
				menuSecundarioAdministrador = false;
				break;

			// Opcion incorrecta
			default:
				System.out.println("Por favor para ayudarte a encontrar lo que buscas indica un valor correcto");
				menuSecundarioAdministrador = true;
				break;
			}

		} while (menuSecundarioAdministrador);
		return cantidadPersonasId;
	}

	/*
	 * Método para dar de alta un administrador
	 */
	public static Administrador darDeAltaAdministrador(int cantidadPersonasId) {

		Administrador usuarioNuevo = new Administrador();
		cantidadPersonasId++;
		usuarioNuevo.setIdAlta(cantidadPersonasId);
		String nombre = UtilsParejas.getString("Nombre: ");
		usuarioNuevo.setNombre(nombre);

		String apellido = UtilsParejas.getString("Apellido: ");
		usuarioNuevo.setApellido(apellido);

		String userName = UtilsParejas.getString("Username: ");
		usuarioNuevo.setUserName(userName);

		int departamento = UtilsParejas.capturaValorMenu(
				"Indica a que departamento pertenece el usuario: \n 1. Director \n 2. Administrador \n 3. Responsable: \n 4. Recursos Humanos:",
				4);
		String listDepatamento[] = { "Director", "Administrador", "Responsable", "Recursos Humanos" };
		usuarioNuevo.setDepartamento(listDepatamento[departamento - 1]);

		return usuarioNuevo;

	}

}
