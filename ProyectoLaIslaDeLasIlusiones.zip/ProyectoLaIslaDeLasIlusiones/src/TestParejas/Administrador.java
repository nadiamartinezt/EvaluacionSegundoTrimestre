package TestParejas;

public class Administrador extends PersonasClasePadre{
	
	// Atributos
	String departamento;

	// Constructores
	protected Administrador() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected Administrador(int idAlta, String nombre, String apellido, String userName) {
		super(idAlta, nombre, apellido, userName);
		// TODO Auto-generated constructor stub
	}
	
	//modificado pasando valores de padre
	protected Administrador(int idAlta, String nombre, String apellido, String userName, String departamento) {
		super(idAlta, nombre, apellido, userName);
		this.departamento = departamento;
	}

	protected void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	@Override
	public String toString() {
		return "Administrador [departamento=" + departamento + ", idAlta=" + idAlta + ", nombre=" + nombre
				+ ", apellido=" + apellido + ", userName=" + userName + "]";
	}
	
	
	
	
	
	

}
