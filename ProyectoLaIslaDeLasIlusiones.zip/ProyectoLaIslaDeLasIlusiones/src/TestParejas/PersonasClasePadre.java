package TestParejas;

import java.util.ArrayList;
import java.util.Arrays;

public class PersonasClasePadre {

	// Atributos
	protected int idAlta;
	protected String nombre;
	protected String apellido;
	protected String userName;

	// Contructores
	protected PersonasClasePadre() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected PersonasClasePadre(int idAlta, String nombre, String apellido, String userName) {
		super();
		this.idAlta = idAlta;
		this.nombre = nombre;
		this.apellido = apellido;
		this.userName = userName;
	}

	protected int getIdAlta() {
		return idAlta;
	}

	protected void setIdAlta(int idAlta) {
		this.idAlta = idAlta;
	}

	protected String getNombre() {
		return nombre;
	}

	protected void setNombre(String nombre) {
		this.nombre = nombre;
	}

	protected String getApellido() {
		return apellido;
	}

	protected void setApellido(String apellido) {
		this.apellido = apellido;
	}

	protected String getUserName() {
		return userName;
	}

	protected void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Id=" + idAlta + ", Nombre=" + nombre + ", Apellido=" + apellido;
	}

}
